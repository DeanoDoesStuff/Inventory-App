package com.zybooks.project1;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class DatabaseViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database_view);

        // Initialize RecyclerView
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Create dummy data, this will be replaced by database data
        List<Item> itemList = new ArrayList<>();
        itemList.add(new Item("Classic 40 Center No Light Hole", 10));
        itemList.add(new Item("Classic 40 Center 20In Light Hole", 0));
        itemList.add(new Item("Classic 40 Center Logo Relocated", 8));

        // Set up the adapter with the dummy data
        ItemAdapter itemAdapter = new ItemAdapter(itemList);
        recyclerView.setAdapter(itemAdapter);
    }
}
