package com.zybooks.project1;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText username;
    private EditText password;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Find the username, password, and login button
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);

        // Initially disable the login button
        loginButton.setEnabled(false);

        // Add a TextWatcher to both username and password fields to enable/disable the login button
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Enable the login button if both username and password are non-empty
                checkInputs();
            }
        };

        // Attach the TextWatcher to both username and password fields
        username.addTextChangedListener(textWatcher);
        password.addTextChangedListener(textWatcher);

        // Set an OnClickListener for the login button
        loginButton.setOnClickListener(v -> {
            // Create an intent to open the DatabaseViewActivity (your inventory view screen)
            Intent intent = new Intent(MainActivity.this, DatabaseViewActivity.class);
            startActivity(intent);
        });
    }

    // Method to check if both inputs are filled
    private void checkInputs() {
        String usernameInput = username.getText().toString().trim();
        String passwordInput = password.getText().toString().trim();

        // Enable the button only if both fields have text
        loginButton.setEnabled(!usernameInput.isEmpty() && !passwordInput.isEmpty());
    }

    public void loginButton(View view) {
    }

    public void createAccount(View view) {
    }
}
